#include "dma.h"

#include "usart3.h"


void DMA_init(void)
{
   DMA_InitTypeDef    DMA_Initstructure;
//   NVIC_InitTypeDef   NVIC_Initstructure;
    
   /*����DMAʱ��*/
   RCC_AHBPeriphClockCmd(RCC_AHBPeriph_DMA1,ENABLE);
   
//   /* Enable the DMA1 Interrupt */
//   NVIC_Initstructure.NVIC_IRQChannel = DMA1_Channel4_IRQn;       //ͨ������Ϊ����1�ж�
//   NVIC_Initstructure.NVIC_IRQChannelSubPriority = 1;     //�ж���Ӧ���ȼ�0
//   NVIC_Initstructure.NVIC_IRQChannelPreemptionPriority=1;
//   NVIC_Initstructure.NVIC_IRQChannelCmd = ENABLE;        //���ж�
//   NVIC_Init(&NVIC_Initstructure);  
 
   /*DMA����*/
   DMA_Initstructure.DMA_PeripheralBaseAddr =  (u32)(&USART3->DR);;
   DMA_Initstructure.DMA_MemoryBaseAddr     = (u32)receive_data;
   DMA_Initstructure.DMA_DIR = DMA_DIR_PeripheralSRC;
   DMA_Initstructure.DMA_BufferSize = 128;
   DMA_Initstructure.DMA_PeripheralInc = DMA_PeripheralInc_Disable;
   DMA_Initstructure.DMA_MemoryInc =DMA_MemoryInc_Enable;
   DMA_Initstructure.DMA_PeripheralDataSize = DMA_PeripheralDataSize_Byte;
   DMA_Initstructure.DMA_MemoryDataSize = DMA_MemoryDataSize_Byte;
   DMA_Initstructure.DMA_Mode = DMA_Mode_Normal;
   DMA_Initstructure.DMA_Priority = DMA_Priority_High;
   DMA_Initstructure.DMA_M2M = DMA_M2M_Disable;
   DMA_Init(DMA1_Channel3,&DMA_Initstructure);
   
   //����DMA
   DMA_Cmd(DMA1_Channel3,ENABLE);  
 
   //����DMA���ͷ����ж�
   //DMA_ITConfig(DMA1_Channel4,DMA_IT_TC,ENABLE); 
} 

























